"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Plus,
  Package,
  ShoppingCart,
  MessageCircle,
  User,
  LogOut,
  Eye,
  Edit,
  Trash2,
  Bell,
  DollarSign,
  TrendingUp,
} from "lucide-react"
import Link from "next/link"

const categories = ["Électronique", "Mode", "Maison", "Sport", "Beauté", "Automobile", "Alimentation", "Livres"]

const provinces = ["Brazzaville", "Pointe-Noire", "Dolisie", "Nkayi", "Impfondo", "Ouesso", "Madingou", "Owando"]

export default function SellerDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [products, setProducts] = useState([
    {
      id: 1,
      name: "iPhone 14 Pro",
      category: "Électronique",
      price: "850000",
      quantity: 5,
      image: "/placeholder.svg?height=100&width=100",
      status: "active",
      orders: 12,
    },
    {
      id: 2,
      name: "Robe Africaine",
      category: "Mode",
      price: "25000",
      quantity: 0,
      image: "/placeholder.svg?height=100&width=100",
      status: "out_of_stock",
      orders: 8,
    },
  ])

  const [orders, setOrders] = useState([
    {
      id: "TK001234",
      product: "iPhone 14 Pro",
      customer: "Jean Mbemba",
      phone: "+242065123456",
      address: "Poto-Poto, Brazzaville",
      status: "pending",
      date: "2024-01-15",
      amount: "850000",
    },
    {
      id: "TK001235",
      product: "Robe Africaine",
      customer: "Marie Kongo",
      phone: "+242066789012",
      address: "Centre-ville, Pointe-Noire",
      status: "completed",
      date: "2024-01-14",
      amount: "25000",
    },
  ])

  const [newProduct, setNewProduct] = useState({
    name: "",
    category: "",
    price: "",
    quantity: "",
    description: "",
    meetingPoint: "",
    phone: "+242",
    image: null,
  })

  const [notifications] = useState([
    {
      id: 1,
      message: "Nouvelle commande reçue - Ticket TK001234",
      time: "5 min",
      type: "order",
    },
    {
      id: 2,
      message: 'Votre produit "iPhone 14 Pro" a été consulté 15 fois',
      time: "1h",
      type: "view",
    },
    {
      id: 3,
      message: "Rappel: Taxe mensuelle de 500 FCFA due le 20/01",
      time: "2h",
      type: "payment",
    },
  ])

  const handleAddProduct = (e) => {
    e.preventDefault()
    const product = {
      id: Date.now(),
      ...newProduct,
      status: "active",
      orders: 0,
    }
    setProducts([...products, product])
    setNewProduct({
      name: "",
      category: "",
      price: "",
      quantity: "",
      description: "",
      meetingPoint: "",
      phone: "+242",
      image: null,
    })
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500">Actif</Badge>
      case "out_of_stock":
        return <Badge className="bg-red-500">Rupture</Badge>
      case "pending":
        return <Badge className="bg-yellow-500">En attente</Badge>
      case "completed":
        return <Badge className="bg-green-500">Terminé</Badge>
      default:
        return <Badge>{status}</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-orange-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-gradient-to-r from-sky-400 to-orange-400">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="bg-gradient-to-r from-sky-500 to-orange-500 text-white p-2 rounded-full">
                  <span className="text-xl font-bold">B</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-sky-600 to-orange-600 bg-clip-text text-transparent">
                    BATACLAN
                  </h1>
                  <p className="text-sm text-gray-600">Espace Vendeur</p>
                </div>
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Button variant="outline" size="sm">
                  <Bell className="h-4 w-4" />
                  <Badge className="absolute -top-2 -right-2 bg-red-500 text-xs">{notifications.length}</Badge>
                </Button>
              </div>

              <div className="flex items-center space-x-2">
                <img
                  src="/placeholder.svg?height=40&width=40"
                  alt="Profile"
                  className="w-10 h-10 rounded-full border-2 border-sky-300"
                />
                <div>
                  <p className="font-semibold text-gray-800">Jean Vendeur</p>
                  <p className="text-xs text-gray-600">ID: VND001</p>
                </div>
              </div>

              <Button variant="outline" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                Déconnexion
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-white border-2 border-sky-200">
            <TabsTrigger value="overview" className="data-[state=active]:bg-sky-500 data-[state=active]:text-white">
              <TrendingUp className="mr-2 h-4 w-4" />
              Aperçu
            </TabsTrigger>
            <TabsTrigger value="products" className="data-[state=active]:bg-sky-500 data-[state=active]:text-white">
              <Package className="mr-2 h-4 w-4" />
              Produits
            </TabsTrigger>
            <TabsTrigger value="orders" className="data-[state=active]:bg-sky-500 data-[state=active]:text-white">
              <ShoppingCart className="mr-2 h-4 w-4" />
              Commandes
            </TabsTrigger>
            <TabsTrigger value="messages" className="data-[state=active]:bg-sky-500 data-[state=active]:text-white">
              <MessageCircle className="mr-2 h-4 w-4" />
              Messages
            </TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:bg-sky-500 data-[state=active]:text-white">
              <User className="mr-2 h-4 w-4" />
              Profil
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card className="border-2 border-sky-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Produits Actifs</p>
                      <p className="text-3xl font-bold text-sky-600">
                        {products.filter((p) => p.status === "active").length}
                      </p>
                    </div>
                    <Package className="h-8 w-8 text-sky-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-orange-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Commandes</p>
                      <p className="text-3xl font-bold text-orange-600">{orders.length}</p>
                    </div>
                    <ShoppingCart className="h-8 w-8 text-orange-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-green-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Revenus</p>
                      <p className="text-3xl font-bold text-green-600">875,000 FCFA</p>
                    </div>
                    <DollarSign className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-2 border-purple-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Messages</p>
                      <p className="text-3xl font-bold text-purple-600">5</p>
                    </div>
                    <MessageCircle className="h-8 w-8 text-purple-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Notifications */}
            <Card className="border-2 border-sky-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bell className="mr-2 h-5 w-5" />
                  Notifications Récentes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {notifications.map((notification) => (
                    <div key={notification.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <p className="text-sm">{notification.message}</p>
                      <span className="text-xs text-gray-500">{notification.time}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-800">Mes Produits</h2>
              <Button className="bg-gradient-to-r from-sky-500 to-orange-500">
                <Plus className="mr-2 h-4 w-4" />
                Ajouter un Produit
              </Button>
            </div>

            {/* Add Product Form */}
            <Card className="border-2 border-sky-200">
              <CardHeader>
                <CardTitle>Publier un Nouveau Produit</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddProduct} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Nom du produit *</Label>
                      <Input
                        value={newProduct.name}
                        onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                        placeholder="Ex: iPhone 14 Pro"
                        required
                      />
                    </div>
                    <div>
                      <Label>Catégorie *</Label>
                      <select
                        value={newProduct.category}
                        onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                        className="w-full px-3 py-2 border rounded-md"
                        required
                      >
                        <option value="">Sélectionner une catégorie</option>
                        {categories.map((cat) => (
                          <option key={cat} value={cat}>
                            {cat}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Prix (FCFA) *</Label>
                      <Input
                        type="number"
                        value={newProduct.price}
                        onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                        placeholder="25000"
                        required
                      />
                    </div>
                    <div>
                      <Label>Quantité *</Label>
                      <Input
                        type="number"
                        value={newProduct.quantity}
                        onChange={(e) => setNewProduct({ ...newProduct, quantity: e.target.value })}
                        placeholder="10"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Photo du produit *</Label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => setNewProduct({ ...newProduct, image: e.target.files[0] })}
                      required
                    />
                  </div>

                  <div>
                    <Label>Point de rencontre *</Label>
                    <Input
                      value={newProduct.meetingPoint}
                      onChange={(e) => setNewProduct({ ...newProduct, meetingPoint: e.target.value })}
                      placeholder="Ex: Centre commercial, Poto-Poto"
                      required
                    />
                  </div>

                  <div>
                    <Label>Votre numéro de téléphone *</Label>
                    <Input
                      value={newProduct.phone}
                      onChange={(e) => setNewProduct({ ...newProduct, phone: e.target.value })}
                      placeholder="+242065123456"
                      required
                    />
                  </div>

                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={newProduct.description}
                      onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                      placeholder="Description détaillée du produit..."
                      rows={3}
                    />
                  </div>

                  <Button type="submit" className="w-full bg-gradient-to-r from-sky-500 to-orange-500">
                    Publier le Produit
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Products List */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((product) => (
                <Card key={product.id} className="border-2 border-sky-200">
                  <CardContent className="p-4">
                    <img
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      className="w-full h-32 object-cover rounded-lg mb-4"
                    />
                    <h3 className="font-bold text-lg mb-2">{product.name}</h3>
                    <p className="text-orange-600 font-bold text-xl mb-2">{product.price} FCFA</p>
                    <p className="text-sm text-gray-600 mb-2">Quantité: {product.quantity}</p>
                    <p className="text-sm text-gray-600 mb-4">Commandes: {product.orders}</p>

                    <div className="flex items-center justify-between mb-4">
                      {getStatusBadge(product.status)}
                      <Badge variant="outline">{product.category}</Badge>
                    </div>

                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                        <Eye className="h-4 w-4 mr-1" />
                        Voir
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                        <Edit className="h-4 w-4 mr-1" />
                        Modifier
                      </Button>
                      <Button size="sm" variant="outline" className="text-red-600 border-red-300 bg-transparent">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Mes Commandes</h2>

            <Card className="border-2 border-sky-200">
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-sky-50">
                      <tr>
                        <th className="px-4 py-3 text-left">Ticket</th>
                        <th className="px-4 py-3 text-left">Produit</th>
                        <th className="px-4 py-3 text-left">Client</th>
                        <th className="px-4 py-3 text-left">Téléphone</th>
                        <th className="px-4 py-3 text-left">Adresse</th>
                        <th className="px-4 py-3 text-left">Montant</th>
                        <th className="px-4 py-3 text-left">Statut</th>
                        <th className="px-4 py-3 text-left">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {orders.map((order) => (
                        <tr key={order.id} className="border-b">
                          <td className="px-4 py-3 font-mono text-sm">{order.id}</td>
                          <td className="px-4 py-3">{order.product}</td>
                          <td className="px-4 py-3">{order.customer}</td>
                          <td className="px-4 py-3">{order.phone}</td>
                          <td className="px-4 py-3">{order.address}</td>
                          <td className="px-4 py-3 font-bold text-orange-600">{order.amount} FCFA</td>
                          <td className="px-4 py-3">{getStatusBadge(order.status)}</td>
                          <td className="px-4 py-3">
                            <div className="flex gap-2">
                              <Button size="sm" variant="outline">
                                <MessageCircle className="h-4 w-4" />
                              </Button>
                              <Button size="sm" className="bg-green-500 hover:bg-green-600">
                                Valider
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages" className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Messages</h2>

            <Card className="border-2 border-sky-200">
              <CardContent className="p-6">
                <div className="text-center py-12">
                  <MessageCircle className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">Interface de Discussion</h3>
                  <p className="text-gray-500 mb-6">
                    Ici, vous pourrez discuter directement avec vos clients et les visiteurs intéressés par vos
                    produits.
                  </p>
                  <Button className="bg-gradient-to-r from-sky-500 to-orange-500">
                    Fonctionnalité en développement
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800">Mon Profil</h2>

            <Card className="border-2 border-sky-200">
              <CardHeader>
                <CardTitle>Informations du Vendeur</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4 mb-6">
                  <img
                    src="/placeholder.svg?height=80&width=80"
                    alt="Profile"
                    className="w-20 h-20 rounded-full border-4 border-sky-300"
                  />
                  <div>
                    <h3 className="text-xl font-bold">Jean Vendeur</h3>
                    <p className="text-gray-600">ID Vendeur: VND001</p>
                    <Badge className="bg-green-500 mt-2">Compte Actif</Badge>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Prénom</Label>
                    <Input defaultValue="Jean" />
                  </div>
                  <div>
                    <Label>Nom</Label>
                    <Input defaultValue="Vendeur" />
                  </div>
                </div>

                <div>
                  <Label>Numéro de téléphone</Label>
                  <Input defaultValue="+242065123456" />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Province</Label>
                    <select className="w-full px-3 py-2 border rounded-md" defaultValue="Brazzaville">
                      {provinces.map((province) => (
                        <option key={province} value={province}>
                          {province}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <Label>Quartier</Label>
                    <Input defaultValue="Poto-Poto" />
                  </div>
                </div>

                <div>
                  <Label>Adresse complète</Label>
                  <Textarea defaultValue="Avenue de l'Indépendance, Poto-Poto, Brazzaville" />
                </div>

                <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                  <h4 className="font-semibold text-orange-700 mb-2">💰 Informations de Facturation</h4>
                  <p className="text-sm text-orange-600">
                    Taxe mensuelle: 500 FCFA
                    <br />
                    Prochaine échéance: 20 Janvier 2024
                    <br />
                    Statut: ✅ À jour
                  </p>
                </div>

                <div className="flex gap-4">
                  <Button className="bg-gradient-to-r from-sky-500 to-orange-500">Modifier le Profil</Button>
                  <Button variant="outline">Changer le Mot de Passe</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
