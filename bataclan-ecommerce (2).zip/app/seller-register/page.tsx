"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { User, Phone, Lock, MapPin, Camera, ArrowLeft, Check } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

const provinces = ["Brazzaville", "Pointe-Noire", "Dolisie", "Nkayi", "Impfondo", "Ouesso", "Madingou", "Owando"]

const quartiersByProvince = {
  Brazzaville: ["Poto-Poto", "Bacongo", "Moungali", "Ouenzé", "Talangaï", "Mfilou", "Djiri", "Madibou"],
  "Pointe-Noire": ["Centre-ville", "Tié-Tié", "Lumumba", "Mongo-Mpoukou", "Ngoyo", "Mvou-Mvou"],
  Dolisie: ["Centre", "Ngot", "Moukoukoulou", "Bikoumat"],
  Nkayi: ["Centre", "Loudima", "Mouyondzi"],
  Impfondo: ["Centre", "Dongou", "Epena"],
  Ouesso: ["Centre", "Pokola", "Kabo"],
  Madingou: ["Centre", "Divénié", "Kimongo"],
  Owando: ["Centre", "Makoua", "Okoyo"],
}

export default function SellerRegister() {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    password: "",
    confirmPassword: "",
    province: "",
    quartier: "",
    address: "",
    profilePhoto: null,
  })
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState(1)
  const router = useRouter()

  const formatPhoneNumber = (value) => {
    let cleaned = value.replace(/\D/g, "")
    if (!cleaned.startsWith("242")) {
      cleaned = "242" + cleaned.replace(/^242/, "")
    }
    return "+" + cleaned.slice(0, 12)
  }

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: field === "phone" ? formatPhoneNumber(value) : value,
    }))
  }

  const handleFileChange = (e) => {
    const file = e.target.files[0]
    if (file) {
      setFormData((prev) => ({ ...prev, profilePhoto: file }))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (formData.password !== formData.confirmPassword) {
      alert("Les mots de passe ne correspondent pas")
      return
    }

    setLoading(true)

    // Simulation d'inscription
    setTimeout(() => {
      setLoading(false)
      setStep(2) // Étape de confirmation
    }, 2000)
  }

  const completeRegistration = () => {
    router.push("/seller-dashboard")
  }

  if (step === 2) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 to-orange-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-2 border-green-200 shadow-xl">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="h-8 w-8" />
            </div>
            <h2 className="text-2xl font-bold text-green-600 mb-4">Inscription Réussie !</h2>
            <p className="text-gray-600 mb-6">
              Votre compte vendeur a été créé avec succès. Vous pouvez maintenant accéder à votre boutique.
            </p>
            <div className="bg-orange-50 p-4 rounded-lg border border-orange-200 mb-6">
              <p className="text-sm text-orange-700">
                <strong>Rappel:</strong> Taxe mensuelle de 500 FCFA
              </p>
            </div>
            <Button
              onClick={completeRegistration}
              className="w-full bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600"
            >
              Accéder à ma Boutique
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-orange-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/seller-login" className="inline-flex items-center text-sky-600 hover:text-sky-700 mb-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à la connexion
          </Link>

          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="bg-gradient-to-r from-sky-500 to-orange-500 text-white p-3 rounded-full">
              <span className="text-2xl font-bold">B</span>
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-sky-600 to-orange-600 bg-clip-text text-transparent">
              BATACLAN
            </h1>
          </div>
          <p className="text-gray-600">Inscription Vendeur</p>
        </div>

        <Card className="border-2 border-sky-200 shadow-xl">
          <CardHeader className="bg-gradient-to-r from-sky-500 to-orange-500 text-white rounded-t-lg">
            <CardTitle className="text-2xl text-center">Devenir Vendeur</CardTitle>
            <p className="text-sky-100 text-center">Créez votre boutique sur BATACLAN</p>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Informations personnelles */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">Prénom *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="firstName"
                      placeholder="Votre prénom"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange("firstName", e.target.value)}
                      className="pl-10 border-2 border-sky-200 focus:border-orange-400"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lastName">Nom *</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="lastName"
                      placeholder="Votre nom"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange("lastName", e.target.value)}
                      className="pl-10 border-2 border-sky-200 focus:border-orange-400"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Téléphone */}
              <div className="space-y-2">
                <Label htmlFor="phone">Numéro de téléphone *</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+242065123456"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    className="pl-10 border-2 border-sky-200 focus:border-orange-400"
                    required
                  />
                </div>
                <p className="text-xs text-gray-500">Format: +242XXXXXXXXX</p>
              </div>

              {/* Photo de profil */}
              <div className="space-y-2">
                <Label htmlFor="photo">Photo de profil *</Label>
                <div className="relative">
                  <Camera className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="photo"
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="pl-10 border-2 border-sky-200 focus:border-orange-400"
                    required
                  />
                </div>
              </div>

              {/* Localisation */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="province">Province *</Label>
                  <select
                    id="province"
                    value={formData.province}
                    onChange={(e) => handleInputChange("province", e.target.value)}
                    className="w-full px-3 py-2 border-2 border-sky-200 rounded-md focus:border-orange-400"
                    required
                  >
                    <option value="">Sélectionner une province</option>
                    {provinces.map((province) => (
                      <option key={province} value={province}>
                        {province}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quartier">Quartier *</Label>
                  <select
                    id="quartier"
                    value={formData.quartier}
                    onChange={(e) => handleInputChange("quartier", e.target.value)}
                    className="w-full px-3 py-2 border-2 border-sky-200 rounded-md focus:border-orange-400"
                    required
                    disabled={!formData.province}
                  >
                    <option value="">Sélectionner un quartier</option>
                    {formData.province &&
                      quartiersByProvince[formData.province]?.map((quartier) => (
                        <option key={quartier} value={quartier}>
                          {quartier}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              {/* Adresse complète */}
              <div className="space-y-2">
                <Label htmlFor="address">Adresse complète *</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Textarea
                    id="address"
                    placeholder="Adresse détaillée (rue, avenue, immeuble...)"
                    value={formData.address}
                    onChange={(e) => handleInputChange("address", e.target.value)}
                    className="pl-10 border-2 border-sky-200 focus:border-orange-400 min-h-[80px]"
                    required
                  />
                </div>
              </div>

              {/* Mots de passe */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="password">Mot de passe *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="Mot de passe"
                      value={formData.password}
                      onChange={(e) => handleInputChange("password", e.target.value)}
                      className="pl-10 border-2 border-sky-200 focus:border-orange-400"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirmer le mot de passe *</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      placeholder="Confirmer le mot de passe"
                      value={formData.confirmPassword}
                      onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                      className="pl-10 border-2 border-sky-200 focus:border-orange-400"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Info taxe */}
              <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                <p className="text-sm text-orange-700">
                  <strong>💰 Taxe mensuelle:</strong> 500 FCFA seront prélevés chaque mois pour maintenir votre boutique
                  active.
                </p>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600 py-3"
                disabled={loading}
              >
                {loading ? "Inscription en cours..." : "Créer ma Boutique"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-gray-600">
                Déjà inscrit ?{" "}
                <Link href="/seller-login" className="text-sky-600 hover:text-sky-700 font-semibold">
                  Se connecter
                </Link>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
