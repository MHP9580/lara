"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Phone, Lock, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function SellerLogin() {
  const [phone, setPhone] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleLogin = async (e) => {
    e.preventDefault()
    setLoading(true)

    // Simulation de connexion
    setTimeout(() => {
      setLoading(false)
      // Redirection vers le dashboard vendeur
      router.push("/seller-dashboard")
    }, 2000)
  }

  const formatPhoneNumber = (value) => {
    // Forcer le format +242XXXXXXXXX
    let cleaned = value.replace(/\D/g, "")
    if (!cleaned.startsWith("242")) {
      cleaned = "242" + cleaned.replace(/^242/, "")
    }
    return "+" + cleaned.slice(0, 12)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-orange-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center text-sky-600 hover:text-sky-700 mb-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à l'accueil
          </Link>

          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="bg-gradient-to-r from-sky-500 to-orange-500 text-white p-3 rounded-full">
              <span className="text-2xl font-bold">B</span>
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-sky-600 to-orange-600 bg-clip-text text-transparent">
              BATACLAN
            </h1>
          </div>
          <p className="text-gray-600">Espace Vendeur</p>
        </div>

        <Card className="border-2 border-sky-200 shadow-xl">
          <CardHeader className="text-center bg-gradient-to-r from-sky-500 to-orange-500 text-white rounded-t-lg">
            <CardTitle className="text-2xl">Connexion Vendeur</CardTitle>
            <p className="text-sky-100">Accédez à votre boutique</p>
          </CardHeader>

          <CardContent className="p-6">
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-gray-700">
                  Numéro de téléphone
                </Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+242065123456"
                    value={phone}
                    onChange={(e) => setPhone(formatPhoneNumber(e.target.value))}
                    className="pl-10 border-2 border-sky-200 focus:border-orange-400"
                    required
                  />
                </div>
                <p className="text-xs text-gray-500">Format: +242XXXXXXXXX</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-700">
                  Mot de passe
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Votre mot de passe"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 border-2 border-sky-200 focus:border-orange-400"
                    required
                  />
                </div>
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600 py-3"
                disabled={loading}
              >
                {loading ? "Connexion..." : "Se Connecter"}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-gray-600">
                Vous êtes nouveau vendeur ?{" "}
                <Link href="/seller-register" className="text-sky-600 hover:text-sky-700 font-semibold">
                  INSCRIVEZ-VOUS
                </Link>
              </p>
            </div>

            <div className="mt-4 p-4 bg-orange-50 rounded-lg border border-orange-200">
              <p className="text-sm text-orange-700 text-center">
                💡 <strong>Info:</strong> Taxe mensuelle de 500 FCFA pour les vendeurs
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
