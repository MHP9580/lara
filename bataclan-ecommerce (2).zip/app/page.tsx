"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, ShoppingCart, MapPin, Phone, Star, Filter, Menu, X, Truck, Shield, Users } from "lucide-react"
import Link from "next/link"

const categories = [
  { name: "Électronique", icon: "📱", color: "bg-blue-100 text-blue-600" },
  { name: "Mode", icon: "👕", color: "bg-pink-100 text-pink-600" },
  { name: "Maison", icon: "🏠", color: "bg-green-100 text-green-600" },
  { name: "Sport", icon: "⚽", color: "bg-orange-100 text-orange-600" },
  { name: "Beauté", icon: "💄", color: "bg-purple-100 text-purple-600" },
  { name: "Automobile", icon: "🚗", color: "bg-red-100 text-red-600" },
  { name: "Alimentation", icon: "🍎", color: "bg-yellow-100 text-yellow-600" },
  { name: "Livres", icon: "📚", color: "bg-indigo-100 text-indigo-600" },
]

const provinces = ["Brazzaville", "Pointe-Noire", "Dolisie", "Nkayi", "Impfondo", "Ouesso", "Madingou", "Owando"]

const featuredProducts = [
  {
    id: 1,
    name: "iPhone 15 Pro Max",
    price: "1200000",
    originalPrice: "1350000",
    image: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&h=400&fit=crop",
    seller: "TechStore BZV",
    location: "Poto-Poto, Brazzaville",
    rating: 4.9,
    reviews: 127,
    phone: "+242065123456",
    badge: "Nouveau",
    discount: "-11%",
  },
  {
    id: 2,
    name: "Robe Africaine Wax Premium",
    price: "35000",
    originalPrice: "45000",
    image: "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&h=400&fit=crop",
    seller: "Mode Africaine Plus",
    location: "Centre-ville, Pointe-Noire",
    rating: 4.8,
    reviews: 89,
    phone: "+242066789012",
    badge: "Populaire",
    discount: "-22%",
  },
  {
    id: 3,
    name: "MacBook Air M2",
    price: "850000",
    originalPrice: "950000",
    image: "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400&h=400&fit=crop",
    seller: "Informatique Plus",
    location: "Moungali, Brazzaville",
    rating: 4.7,
    reviews: 156,
    phone: "+242067345678",
    badge: "Promo",
    discount: "-11%",
  },
  {
    id: 4,
    name: "Nike Air Jordan Retro",
    price: "125000",
    originalPrice: "150000",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop",
    seller: "Sport Fashion Congo",
    location: "Tié-Tié, Brazzaville",
    rating: 4.6,
    reviews: 203,
    phone: "+242068901234",
    badge: "Tendance",
    discount: "-17%",
  },
  {
    id: 5,
    name: "Samsung Galaxy S24 Ultra",
    price: "950000",
    originalPrice: "1100000",
    image: "https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=400&h=400&fit=crop",
    seller: "Mobile Center",
    location: "Bacongo, Brazzaville",
    rating: 4.8,
    reviews: 94,
    phone: "+242069876543",
    badge: "Nouveau",
    discount: "-14%",
  },
  {
    id: 6,
    name: "Ensemble Traditionnel Congolais",
    price: "75000",
    originalPrice: "95000",
    image: "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=400&h=400&fit=crop",
    seller: "Tradition Congo",
    location: "Ouenzé, Brazzaville",
    rating: 4.9,
    reviews: 67,
    phone: "+242061234567",
    badge: "Artisanal",
    discount: "-21%",
  },
  {
    id: 7,
    name: "PlayStation 5 + 2 Manettes",
    price: "650000",
    originalPrice: "750000",
    image: "https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400&h=400&fit=crop",
    seller: "Gaming Zone",
    location: "Talangaï, Brazzaville",
    rating: 4.7,
    reviews: 112,
    phone: "+242062345678",
    badge: "Gaming",
    discount: "-13%",
  },
  {
    id: 8,
    name: "Sac à Main Cuir Premium",
    price: "85000",
    originalPrice: "110000",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop",
    seller: "Luxury Bags Congo",
    location: "Centre-ville, Pointe-Noire",
    rating: 4.8,
    reviews: 78,
    phone: "+242063456789",
    badge: "Luxe",
    discount: "-23%",
  },
]

export default function HomePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [selectedProvince, setSelectedProvince] = useState("")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [cart, setCart] = useState([])

  const addToCart = (product) => {
    setCart([...cart, product])
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-orange-50">
      {/* Header */}
      <header className="bg-white shadow-xl border-b-4 border-gradient-to-r from-sky-400 to-orange-400 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="relative">
                <div className="bg-gradient-to-br from-sky-500 to-orange-500 text-white p-3 rounded-2xl shadow-lg">
                  <span className="text-2xl font-bold">B</span>
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white"></div>
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-sky-600 to-orange-600 bg-clip-text text-transparent">
                  BATACLAN
                </h1>
                <p className="text-sm text-gray-600 font-medium">Marketplace du Congo 🇨🇬</p>
              </div>
            </div>

            {/* Search Bar */}
            <div className="hidden md:flex flex-1 max-w-2xl mx-8">
              <div className="relative w-full">
                <Input
                  type="text"
                  placeholder="Rechercher des produits, marques, vendeurs..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-12 pr-4 py-3 w-full border-2 border-sky-200 focus:border-orange-400 rounded-xl shadow-sm"
                />
                <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
              </div>
              <Button className="ml-3 bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600 px-8 rounded-xl shadow-lg">
                Rechercher
              </Button>
            </div>

            {/* Navigation */}
            <div className="hidden md:flex items-center space-x-4">
              <Link href="/seller-login">
                <Button
                  variant="outline"
                  className="border-2 border-sky-500 text-sky-600 hover:bg-sky-50 bg-transparent rounded-xl px-6"
                >
                  Devenir Vendeur
                </Button>
              </Link>
              <Button
                variant="outline"
                className="relative bg-transparent rounded-xl border-2 border-orange-300 hover:bg-orange-50"
              >
                <ShoppingCart className="h-5 w-5" />
                {cart.length > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-orange-500 text-white min-w-[20px] h-5 rounded-full text-xs">
                    {cart.length}
                  </Badge>
                )}
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <Button variant="ghost" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X /> : <Menu />}
            </Button>
          </div>

          {/* Mobile Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden mt-4 pb-4 border-t pt-4">
              <div className="space-y-4">
                <Input
                  type="text"
                  placeholder="Rechercher..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full"
                />
                <Link href="/seller-login">
                  <Button className="w-full bg-gradient-to-r from-sky-500 to-orange-500">Devenir Vendeur</Button>
                </Link>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-sky-600 via-sky-700 to-orange-600 text-white py-20 overflow-hidden">
        <div className="absolute inset-0 bg-black opacity-10"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-sky-600/90 to-orange-600/90"></div>

        <div className="relative container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-6xl font-bold mb-6 leading-tight">
              Bienvenue sur <span className="text-yellow-300">BATACLAN</span>
            </h2>
            <p className="text-xl mb-8 text-sky-100 max-w-2xl mx-auto leading-relaxed">
              La première marketplace du Congo Brazzaville. Achetez et vendez en toute sécurité dans votre quartier avec
              des codes de tickets uniques.
            </p>

            <div className="flex flex-col md:flex-row gap-4 justify-center items-center max-w-4xl mx-auto mb-8">
              <Input
                type="text"
                placeholder="Que recherchez-vous ?"
                className="flex-1 py-4 text-black text-lg rounded-xl border-0 shadow-lg"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <select className="px-6 py-4 rounded-xl text-black text-lg shadow-lg border-0">
                <option value="">Toutes les provinces</option>
                {provinces.map((province) => (
                  <option key={province} value={province}>
                    {province}
                  </option>
                ))}
              </select>
              <Button className="bg-white text-sky-600 hover:bg-gray-100 px-8 py-4 text-lg rounded-xl shadow-lg font-semibold">
                <Search className="mr-2 h-5 w-5" />
                Rechercher
              </Button>
            </div>

            <div className="flex justify-center space-x-8 text-sm">
              <div className="flex items-center">
                <Shield className="mr-2 h-5 w-5" />
                Achat Sécurisé
              </div>
              <div className="flex items-center">
                <Truck className="mr-2 h-5 w-5" />
                Livraison Locale
              </div>
              <div className="flex items-center">
                <Users className="mr-2 h-5 w-5" />
                +1000 Vendeurs
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-8 text-gray-800">Catégories Populaires</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {categories.map((category) => (
              <Card
                key={category.name}
                className="hover:shadow-xl transition-all duration-300 cursor-pointer border-2 hover:border-sky-300 hover:scale-105"
              >
                <CardContent className="p-6 text-center">
                  <div
                    className={`w-16 h-16 mx-auto mb-3 rounded-2xl flex items-center justify-center ${category.color}`}
                  >
                    <span className="text-2xl">{category.icon}</span>
                  </div>
                  <p className="text-sm font-semibold text-gray-700">{category.name}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-sky-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-10">
            <div>
              <h3 className="text-4xl font-bold text-gray-800 mb-2">Produits en Vedette</h3>
              <p className="text-gray-600">Découvrez les meilleures offres du moment</p>
            </div>
            <Button
              variant="outline"
              className="border-2 border-sky-500 text-sky-600 bg-transparent hover:bg-sky-50 rounded-xl"
            >
              <Filter className="mr-2 h-4 w-4" />
              Filtrer
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredProducts.map((product) => (
              <Card
                key={product.id}
                className="hover:shadow-2xl transition-all duration-300 border-0 shadow-lg hover:scale-105 bg-white rounded-2xl overflow-hidden"
              >
                <CardHeader className="p-0 relative">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-56 object-cover"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge
                      className={`${
                        product.badge === "Nouveau"
                          ? "bg-green-500"
                          : product.badge === "Populaire"
                            ? "bg-blue-500"
                            : product.badge === "Promo"
                              ? "bg-red-500"
                              : product.badge === "Tendance"
                                ? "bg-purple-500"
                                : product.badge === "Gaming"
                                  ? "bg-indigo-500"
                                  : product.badge === "Luxe"
                                    ? "bg-yellow-500"
                                    : product.badge === "Artisanal"
                                      ? "bg-orange-500"
                                      : "bg-gray-500"
                      } text-white font-semibold px-3 py-1 rounded-full`}
                    >
                      {product.badge}
                    </Badge>
                  </div>
                  {product.discount && (
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-red-500 text-white font-bold px-2 py-1 rounded-full">
                        {product.discount}
                      </Badge>
                    </div>
                  )}
                </CardHeader>
                <CardContent className="p-6">
                  <h4 className="font-bold text-lg mb-3 text-gray-800 line-clamp-2">{product.name}</h4>

                  <div className="flex items-center mb-3">
                    <span className="text-2xl font-bold text-orange-600">{product.price} FCFA</span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-500 line-through ml-2">{product.originalPrice} FCFA</span>
                    )}
                  </div>

                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="ml-1 text-sm font-semibold text-gray-700">{product.rating}</span>
                    </div>
                    <span className="text-sm text-gray-500 ml-1">({product.reviews} avis)</span>
                  </div>

                  <div className="flex items-center text-sm text-gray-600 mb-3">
                    <MapPin className="h-4 w-4 mr-1 text-sky-500" />
                    <span className="truncate">{product.location}</span>
                  </div>

                  <div className="flex items-center text-sm text-gray-600 mb-4">
                    <Phone className="h-4 w-4 mr-1 text-green-500" />
                    <span>{product.phone}</span>
                  </div>

                  <p className="text-sm text-sky-600 mb-4 font-medium">Vendeur: {product.seller}</p>

                  <div className="flex gap-2">
                    <Link href={`/product/${product.id}`} className="flex-1">
                      <Button className="w-full bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600 rounded-xl font-semibold">
                        Voir Détails
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      onClick={() => addToCart(product)}
                      className="border-2 border-orange-500 text-orange-600 hover:bg-orange-50 rounded-xl"
                    >
                      <ShoppingCart className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button className="bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600 px-8 py-3 rounded-xl text-lg font-semibold">
              Voir Plus de Produits
            </Button>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-bold text-gray-800 mb-4">Pourquoi Choisir BATACLAN ?</h3>
            <p className="text-gray-600 max-w-2xl mx-auto">
              La marketplace de confiance du Congo Brazzaville avec des fonctionnalités uniques pour votre sécurité
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center border-2 border-sky-200 hover:shadow-xl transition-all duration-300 rounded-2xl">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-gradient-to-br from-sky-500 to-sky-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <MapPin className="h-10 w-10" />
                </div>
                <h4 className="text-xl font-bold mb-4 text-gray-800">Livraison Locale</h4>
                <p className="text-gray-600 leading-relaxed">
                  Rencontrez vos vendeurs dans votre quartier au Congo Brazzaville. Points de rencontre sécurisés dans
                  toutes les provinces.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-2 border-orange-200 hover:shadow-xl transition-all duration-300 rounded-2xl">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Phone className="h-10 w-10" />
                </div>
                <h4 className="text-xl font-bold mb-4 text-gray-800">Contact Direct</h4>
                <p className="text-gray-600 leading-relaxed">
                  Communiquez directement avec les vendeurs via téléphone. Numéros vérifiés au format congolais (+242).
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-2 border-green-200 hover:shadow-xl transition-all duration-300 rounded-2xl">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <ShoppingCart className="h-10 w-10" />
                </div>
                <h4 className="text-xl font-bold mb-4 text-gray-800">Codes de Tickets</h4>
                <p className="text-gray-600 leading-relaxed">
                  Système de tickets uniques pour chaque commande. Sécurité maximale pour vos achats et ventes.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-sky-600 to-orange-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">1000+</div>
              <div className="text-sky-100">Vendeurs Actifs</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">5000+</div>
              <div className="text-sky-100">Produits en Ligne</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">15000+</div>
              <div className="text-sky-100">Commandes Réalisées</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">9</div>
              <div className="text-sky-100">Provinces Couvertes</div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="bg-gradient-to-br from-sky-500 to-orange-500 text-white p-3 rounded-2xl">
                  <span className="text-xl font-bold">B</span>
                </div>
                <span className="text-2xl font-bold">BATACLAN</span>
              </div>
              <p className="text-gray-400 mb-4">
                La marketplace #1 du Congo Brazzaville. Achetez et vendez en toute sécurité avec nos codes de tickets
                uniques.
              </p>
              <div className="flex space-x-4">
                <div className="w-10 h-10 bg-sky-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-sky-700">
                  <span className="text-sm font-bold">f</span>
                </div>
                <div className="w-10 h-10 bg-sky-400 rounded-full flex items-center justify-center cursor-pointer hover:bg-sky-500">
                  <span className="text-sm font-bold">t</span>
                </div>
                <div className="w-10 h-10 bg-pink-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-pink-700">
                  <span className="text-sm font-bold">i</span>
                </div>
              </div>
            </div>

            <div>
              <h5 className="font-bold mb-6 text-lg">Liens Rapides</h5>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    À Propos
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white transition-colors">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/help" className="hover:text-white transition-colors">
                    Centre d'Aide
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white transition-colors">
                    Conditions d'Utilisation
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold mb-6 text-lg">Vendeurs</h5>
              <ul className="space-y-3 text-gray-400">
                <li>
                  <Link href="/seller-login" className="hover:text-white transition-colors">
                    Connexion Vendeur
                  </Link>
                </li>
                <li>
                  <Link href="/seller-register" className="hover:text-white transition-colors">
                    Devenir Vendeur
                  </Link>
                </li>
                <li>
                  <Link href="/seller-guide" className="hover:text-white transition-colors">
                    Guide Vendeur
                  </Link>
                </li>
                <li>
                  <Link href="/seller-fees" className="hover:text-white transition-colors">
                    Tarifs (500 FCFA/mois)
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h5 className="font-bold mb-6 text-lg">Contact</h5>
              <div className="space-y-3 text-gray-400">
                <p className="flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  +242 06 123 4567
                </p>
                <p className="flex items-center">
                  <span className="h-4 w-4 mr-2">📧</span>
                  contact@bataclan.cg
                </p>
                <p className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2" />
                  Brazzaville, Congo 🇨🇬
                </p>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400">
            <p>
              &copy; 2024 BATACLAN. Tous droits réservés. | Taxe mensuelle vendeurs: 500 FCFA | Made with ❤️ in Congo
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
