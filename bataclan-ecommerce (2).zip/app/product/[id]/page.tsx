"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ArrowLeft, Star, MapPin, Phone, MessageCircle, ShoppingCart, User, Shield, Check, Copy } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

const provinces = ["Brazzaville", "Pointe-Noire", "Dolisie", "Nkayi", "Impfondo", "Ouesso", "Madingou", "Owando"]

const quartiersByProvince = {
  Brazzaville: ["Poto-Poto", "Bacongo", "Moungali", "Ouenzé", "Talangaï", "Mfilou", "Djiri", "Madibou"],
  "Pointe-Noire": ["Centre-ville", "Tié-Tié", "Lumumba", "Mongo-Mpoukou", "Ngoyo", "Mvou-Mvou"],
  Dolisie: ["Centre", "Ngot", "Moukoukoulou", "Bikoumat"],
  Nkayi: ["Centre", "Loudima", "Mouyondzi"],
  Impfondo: ["Centre", "Dongou", "Epena"],
  Ouesso: ["Centre", "Pokola", "Kabo"],
  Madingou: ["Centre", "Divénié", "Kimongo"],
  Owando: ["Centre", "Makoua", "Okoyo"],
}

export default function ProductDetail({ params }: { params: { id: string } }) {
  const [quantity, setQuantity] = useState(1)
  const [showOrderForm, setShowOrderForm] = useState(false)
  const [orderForm, setOrderForm] = useState({
    firstName: "",
    lastName: "",
    phone: "+242",
    province: "",
    quartier: "",
    address: "",
    message: "",
  })
  const [orderSuccess, setOrderSuccess] = useState(false)
  const [ticketCode, setTicketCode] = useState("")
  const [ticketCopied, setTicketCopied] = useState(false)
  const router = useRouter()

  // Données du produit avec vraies images
  const product = {
    id: Number.parseInt(params.id),
    name:
      params.id === "1"
        ? "iPhone 15 Pro Max"
        : params.id === "2"
          ? "Robe Africaine Wax Premium"
          : params.id === "3"
            ? "MacBook Air M2"
            : params.id === "4"
              ? "Nike Air Jordan Retro"
              : "iPhone 15 Pro Max",
    price:
      params.id === "1"
        ? "1200000"
        : params.id === "2"
          ? "35000"
          : params.id === "3"
            ? "850000"
            : params.id === "4"
              ? "125000"
              : "1200000",
    originalPrice:
      params.id === "1"
        ? "1350000"
        : params.id === "2"
          ? "45000"
          : params.id === "3"
            ? "950000"
            : params.id === "4"
              ? "150000"
              : "1350000",
    images:
      params.id === "1"
        ? [
            "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&h=600&fit=crop",
            "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&h=400&fit=crop",
            "https://images.unsplash.com/photo-1695048007709-d0b7d2e2e3e5?w=400&h=400&fit=crop",
          ]
        : params.id === "2"
          ? [
              "https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=600&h=600&fit=crop",
              "https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=400&h=400&fit=crop",
            ]
          : params.id === "3"
            ? [
                "https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=600&h=600&fit=crop",
                "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=400&fit=crop",
              ]
            : params.id === "4"
              ? [
                  "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&h=600&fit=crop",
                  "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop",
                ]
              : ["https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=600&h=600&fit=crop"],
    description:
      params.id === "1"
        ? "iPhone 15 Pro Max neuf, couleur Titane Naturel, 256GB. Livré avec tous les accessoires d'origine dans sa boîte scellée. Garantie Apple valide 1 an. Écran Super Retina XDR de 6.7 pouces, puce A17 Pro, système de caméra Pro avec zoom optique 5x."
        : params.id === "2"
          ? "Magnifique robe africaine en tissu Wax 100% coton de qualité premium. Motifs traditionnels congolais authentiques. Coupe élégante et moderne, parfaite pour les occasions spéciales. Tailles disponibles : S, M, L, XL. Confectionnée par des artisans locaux."
          : params.id === "3"
            ? "MacBook Air M2 13 pouces, puce Apple M2 8 cœurs, 8GB RAM, 256GB SSD. Couleur Gris Sidéral. État neuf, encore sous garantie Apple. Parfait pour le travail, les études et la création. Autonomie exceptionnelle jusqu'à 18 heures."
            : params.id === "4"
              ? "Nike Air Jordan Retro authentiques, coloris Chicago. Pointures disponibles du 40 au 45. État neuf avec boîte d'origine. Cuir premium, semelle Air pour un confort optimal. Édition limitée, parfait pour les collectionneurs et amateurs de sneakers."
              : "iPhone 15 Pro Max neuf avec tous les accessoires.",
    seller: {
      name:
        params.id === "1"
          ? "TechStore BZV"
          : params.id === "2"
            ? "Mode Africaine Plus"
            : params.id === "3"
              ? "Informatique Plus"
              : params.id === "4"
                ? "Sport Fashion Congo"
                : "TechStore BZV",
      rating:
        params.id === "1" ? 4.9 : params.id === "2" ? 4.8 : params.id === "3" ? 4.7 : params.id === "4" ? 4.6 : 4.9,
      reviews:
        params.id === "1" ? 127 : params.id === "2" ? 89 : params.id === "3" ? 156 : params.id === "4" ? 203 : 127,
      phone:
        params.id === "1"
          ? "+242065123456"
          : params.id === "2"
            ? "+242066789012"
            : params.id === "3"
              ? "+242067345678"
              : params.id === "4"
                ? "+242068901234"
                : "+242065123456",
      location:
        params.id === "1"
          ? "Poto-Poto, Brazzaville"
          : params.id === "2"
            ? "Centre-ville, Pointe-Noire"
            : params.id === "3"
              ? "Moungali, Brazzaville"
              : params.id === "4"
                ? "Tié-Tié, Brazzaville"
                : "Poto-Poto, Brazzaville",
      joinDate: "Janvier 2023",
    },
    category:
      params.id === "1"
        ? "Électronique"
        : params.id === "2"
          ? "Mode"
          : params.id === "3"
            ? "Électronique"
            : params.id === "4"
              ? "Sport"
              : "Électronique",
    condition: "Neuf",
    availability: "En stock",
    meetingPoint:
      params.id === "1"
        ? "Centre commercial de Poto-Poto"
        : params.id === "2"
          ? "Marché central de Pointe-Noire"
          : params.id === "3"
            ? "Université Marien Ngouabi"
            : params.id === "4"
              ? "Stade Alphonse Massamba-Débat"
              : "Centre commercial de Poto-Poto",
    specifications:
      params.id === "1"
        ? [
            "Écran: 6.7 pouces Super Retina XDR",
            "Processeur: A17 Pro Bionic",
            "Stockage: 256GB",
            "Caméra: 48MP + 12MP + 12MP",
            "Batterie: Jusqu'à 29h de lecture vidéo",
            "Couleur: Titane Naturel",
          ]
        : params.id === "2"
          ? [
              "Matière: 100% Coton Wax",
              "Origine: Artisanat congolais",
              "Tailles: S, M, L, XL disponibles",
              "Motifs: Traditionnels authentiques",
              "Entretien: Lavage à la main recommandé",
            ]
          : params.id === "3"
            ? [
                "Processeur: Apple M2 8 cœurs",
                "Mémoire: 8GB RAM unifiée",
                "Stockage: 256GB SSD",
                "Écran: 13.6 pouces Liquid Retina",
                "Autonomie: Jusqu'à 18 heures",
                "Couleur: Gris Sidéral",
              ]
            : params.id === "4"
              ? [
                  "Marque: Nike Air Jordan",
                  "Modèle: Retro Chicago",
                  "Matière: Cuir premium",
                  "Semelle: Air cushioning",
                  "Pointures: 40-45 disponibles",
                  "État: Neuf avec boîte",
                ]
              : ["Écran: 6.7 pouces Super Retina XDR", "Processeur: A17 Pro Bionic"],
  }

  const formatPhoneNumber = (value: string) => {
    let cleaned = value.replace(/\D/g, "")
    if (!cleaned.startsWith("242")) {
      cleaned = "242" + cleaned.replace(/^242/, "")
    }
    return "+" + cleaned.slice(0, 12)
  }

  const generateTicketCode = () => {
    return "TK" + Date.now().toString().slice(-6)
  }

  const handleOrderSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const ticket = generateTicketCode()
    setTicketCode(ticket)
    setOrderSuccess(true)
    setShowOrderForm(false)
  }

  const copyTicketCode = () => {
    navigator.clipboard.writeText(ticketCode)
    setTicketCopied(true)
    setTimeout(() => setTicketCopied(false), 2000)
  }

  if (orderSuccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-sky-50 to-orange-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg border-2 border-green-200 shadow-2xl rounded-2xl">
          <CardContent className="p-8 text-center">
            <div className="w-20 h-20 bg-green-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              <Check className="h-10 w-10" />
            </div>
            <h2 className="text-3xl font-bold text-green-600 mb-4">Commande Confirmée !</h2>

            <div className="bg-gradient-to-r from-sky-50 to-orange-50 p-6 rounded-xl mb-6 border-2 border-sky-200">
              <p className="text-sm text-gray-600 mb-3">Votre code de ticket unique :</p>
              <div className="flex items-center justify-center space-x-3">
                <p className="text-3xl font-bold text-sky-600 font-mono bg-white px-4 py-2 rounded-lg border-2 border-sky-300">
                  {ticketCode}
                </p>
                <Button
                  onClick={copyTicketCode}
                  variant="outline"
                  size="sm"
                  className="border-sky-300 text-sky-600 hover:bg-sky-50 bg-transparent"
                >
                  {ticketCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              {ticketCopied && <p className="text-sm text-green-600 mt-2">✅ Code copié !</p>}
            </div>

            <div className="bg-orange-50 p-4 rounded-lg mb-6 border border-orange-200">
              <h4 className="font-semibold text-orange-700 mb-2">📋 Instructions importantes :</h4>
              <ul className="text-sm text-orange-600 text-left space-y-1">
                <li>• Notez ce code précieusement</li>
                <li>• Présentez-le au vendeur lors de la rencontre</li>
                <li>• Vérifiez le produit avant paiement</li>
                <li>• Le vendeur a reçu le même code</li>
              </ul>
            </div>

            <div className="space-y-3">
              <Button
                onClick={() => router.push("/")}
                className="w-full bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600 rounded-xl py-3"
              >
                Retour à l'accueil
              </Button>
              <Button
                variant="outline"
                onClick={() => (window.location.href = `tel:${product.seller.phone}`)}
                className="w-full border-2 border-green-500 text-green-600 hover:bg-green-50 rounded-xl"
              >
                <Phone className="mr-2 h-4 w-4" />
                Contacter le vendeur
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-orange-50">
      {/* Header */}
      <header className="bg-white shadow-xl border-b-4 border-gradient-to-r from-sky-400 to-orange-400 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-3">
              <ArrowLeft className="h-5 w-5 text-sky-600" />
              <div className="bg-gradient-to-br from-sky-500 to-orange-500 text-white p-2 rounded-2xl">
                <span className="text-xl font-bold">B</span>
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-sky-600 to-orange-600 bg-clip-text text-transparent">
                BATACLAN
              </h1>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Images du produit */}
          <div className="space-y-4">
            <div className="aspect-square bg-white rounded-2xl border-2 border-sky-200 overflow-hidden shadow-lg">
              <img
                src={product.images[0] || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
            {product.images.length > 1 && (
              <div className="grid grid-cols-3 gap-3">
                {product.images.slice(1).map((image, index) => (
                  <div
                    key={index}
                    className="aspect-square bg-white rounded-xl border-2 border-sky-200 overflow-hidden cursor-pointer hover:border-orange-400 transition-colors shadow-md"
                  >
                    <img
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} ${index + 2}`}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Informations du produit */}
          <div className="space-y-8">
            <div>
              <Badge className="mb-3 bg-sky-100 text-sky-600 px-3 py-1 rounded-full">{product.category}</Badge>
              <h1 className="text-4xl font-bold text-gray-800 mb-4 leading-tight">{product.name}</h1>

              <div className="flex items-center space-x-4 mb-6">
                <span className="text-4xl font-bold text-orange-600">{product.price} FCFA</span>
                {product.originalPrice && (
                  <span className="text-xl text-gray-500 line-through">{product.originalPrice} FCFA</span>
                )}
                {product.originalPrice && (
                  <Badge className="bg-red-500 text-white">
                    -{Math.round((1 - Number(product.price) / Number(product.originalPrice)) * 100)}%
                  </Badge>
                )}
              </div>

              <div className="flex items-center space-x-4 mb-6">
                <Badge className="bg-green-500 text-white px-4 py-2">{product.availability}</Badge>
                <Badge variant="outline" className="border-2 border-sky-300 text-sky-600 px-4 py-2">
                  {product.condition}
                </Badge>
              </div>
            </div>

            {/* Informations du vendeur */}
            <Card className="border-2 border-sky-200 rounded-2xl shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4 mb-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-sky-500 to-orange-500 text-white rounded-2xl flex items-center justify-center shadow-lg">
                    <User className="h-8 w-8" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-800">{product.seller.name}</h3>
                    <div className="flex items-center">
                      <div className="flex items-center mr-3">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < Math.floor(product.seller.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-semibold">
                        {product.seller.rating} ({product.seller.reviews} avis)
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 text-gray-700">
                  <div className="flex items-center">
                    <MapPin className="h-5 w-5 mr-3 text-sky-500" />
                    <span className="font-medium">{product.seller.location}</span>
                  </div>
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 mr-3 text-green-500" />
                    <span className="font-medium">{product.seller.phone}</span>
                  </div>
                  <div className="bg-sky-50 p-3 rounded-lg">
                    <p className="text-sm">
                      <strong>Point de rencontre:</strong> {product.meetingPoint}
                    </p>
                  </div>
                  <p className="text-sm text-gray-600">Membre depuis: {product.seller.joinDate}</p>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <Label className="text-lg font-semibold">Quantité:</Label>
                <div className="flex items-center space-x-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 rounded-full border-2 border-sky-300"
                  >
                    -
                  </Button>
                  <span className="px-6 py-2 border-2 border-sky-200 rounded-lg font-bold text-lg">{quantity}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 rounded-full border-2 border-sky-300"
                  >
                    +
                  </Button>
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  onClick={() => setShowOrderForm(true)}
                  className="flex-1 bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600 py-4 text-lg font-semibold rounded-xl shadow-lg"
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Commander Maintenant
                </Button>
                <Button
                  variant="outline"
                  onClick={() => (window.location.href = `tel:${product.seller.phone}`)}
                  className="border-2 border-green-500 text-green-600 hover:bg-green-50 px-6 rounded-xl"
                >
                  <Phone className="mr-2 h-4 w-4" />
                  Appeler
                </Button>
                <Button
                  variant="outline"
                  className="border-2 border-orange-500 text-orange-600 hover:bg-orange-50 px-6 rounded-xl bg-transparent"
                >
                  <MessageCircle className="mr-2 h-4 w-4" />
                  Message
                </Button>
              </div>
            </div>

            {/* Sécurité */}
            <Card className="border-2 border-green-200 bg-green-50 rounded-2xl">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Shield className="h-6 w-6 text-green-600 mr-3" />
                  <h4 className="text-xl font-bold text-green-700">Achat Sécurisé BATACLAN</h4>
                </div>
                <ul className="text-sm text-green-600 space-y-2">
                  <li className="flex items-center">
                    <Check className="h-4 w-4 mr-2" />
                    Code de ticket unique pour chaque commande
                  </li>
                  <li className="flex items-center">
                    <Check className="h-4 w-4 mr-2" />
                    Contact direct avec le vendeur vérifié
                  </li>
                  <li className="flex items-center">
                    <Check className="h-4 w-4 mr-2" />
                    Rencontre en personne avant paiement
                  </li>
                  <li className="flex items-center">
                    <Check className="h-4 w-4 mr-2" />
                    Vérification du produit sur place
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Description et spécifications */}
        <div className="mt-16 grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="border-2 border-sky-200 rounded-2xl shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-800">Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed text-lg">{product.description}</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-orange-200 rounded-2xl shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-gray-800">Spécifications</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {product.specifications.map((spec, index) => (
                  <li key={index} className="text-gray-700 flex items-start">
                    <span className="text-orange-500 mr-2">•</span>
                    <span className="text-lg">{spec}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Formulaire de commande */}
      {showOrderForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl border-2 border-sky-200 max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl">
            <CardHeader className="bg-gradient-to-r from-sky-500 to-orange-500 text-white rounded-t-2xl">
              <CardTitle className="text-2xl">Finaliser la Commande</CardTitle>
              <p className="text-sky-100 text-lg">
                {product.name} - {Number(product.price) * quantity} FCFA
              </p>
            </CardHeader>

            <CardContent className="p-8">
              <form onSubmit={handleOrderSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-lg font-semibold">Prénom *</Label>
                    <Input
                      value={orderForm.firstName}
                      onChange={(e) => setOrderForm({ ...orderForm, firstName: e.target.value })}
                      className="mt-2 py-3 text-lg rounded-xl border-2 border-sky-200"
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-lg font-semibold">Nom *</Label>
                    <Input
                      value={orderForm.lastName}
                      onChange={(e) => setOrderForm({ ...orderForm, lastName: e.target.value })}
                      className="mt-2 py-3 text-lg rounded-xl border-2 border-sky-200"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-lg font-semibold">Numéro de téléphone *</Label>
                  <Input
                    type="tel"
                    value={orderForm.phone}
                    onChange={(e) => setOrderForm({ ...orderForm, phone: formatPhoneNumber(e.target.value) })}
                    placeholder="+242065123456"
                    className="mt-2 py-3 text-lg rounded-xl border-2 border-sky-200"
                    required
                  />
                  <p className="text-sm text-gray-500 mt-2">Format congolais requis: +242XXXXXXXXX</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-lg font-semibold">Province *</Label>
                    <select
                      value={orderForm.province}
                      onChange={(e) => setOrderForm({ ...orderForm, province: e.target.value, quartier: "" })}
                      className="w-full mt-2 px-4 py-3 border-2 border-sky-200 rounded-xl text-lg"
                      required
                    >
                      <option value="">Sélectionner une province</option>
                      {provinces.map((province) => (
                        <option key={province} value={province}>
                          {province}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <Label className="text-lg font-semibold">Quartier *</Label>
                    <select
                      value={orderForm.quartier}
                      onChange={(e) => setOrderForm({ ...orderForm, quartier: e.target.value })}
                      className="w-full mt-2 px-4 py-3 border-2 border-sky-200 rounded-xl text-lg"
                      required
                      disabled={!orderForm.province}
                    >
                      <option value="">Sélectionner un quartier</option>
                      {orderForm.province &&
                        quartiersByProvince[orderForm.province]?.map((quartier) => (
                          <option key={quartier} value={quartier}>
                            {quartier}
                          </option>
                        ))}
                    </select>
                  </div>
                </div>

                <div>
                  <Label className="text-lg font-semibold">Adresse complète *</Label>
                  <Textarea
                    value={orderForm.address}
                    onChange={(e) => setOrderForm({ ...orderForm, address: e.target.value })}
                    placeholder="Adresse détaillée pour la rencontre..."
                    className="mt-2 rounded-xl border-2 border-sky-200 min-h-[100px] text-lg"
                    required
                  />
                </div>

                <div>
                  <Label className="text-lg font-semibold">Message pour le vendeur (optionnel)</Label>
                  <Textarea
                    value={orderForm.message}
                    onChange={(e) => setOrderForm({ ...orderForm, message: e.target.value })}
                    placeholder="Questions ou instructions spéciales..."
                    className="mt-2 rounded-xl border-2 border-sky-200 min-h-[80px] text-lg"
                  />
                </div>

                <div className="bg-gradient-to-r from-orange-50 to-sky-50 p-6 rounded-xl border-2 border-orange-200">
                  <h4 className="text-xl font-bold text-orange-700 mb-4">📋 Résumé de la commande</h4>
                  <div className="text-orange-600 space-y-2">
                    <p className="text-lg">
                      <strong>Produit:</strong> {product.name}
                    </p>
                    <p className="text-lg">
                      <strong>Quantité:</strong> {quantity}
                    </p>
                    <p className="text-lg">
                      <strong>Prix unitaire:</strong> {product.price} FCFA
                    </p>
                    <p className="text-xl font-bold border-t border-orange-300 pt-2">
                      <strong>Total: {Number(product.price) * quantity} FCFA</strong>
                    </p>
                    <p className="text-lg">
                      <strong>Point de rencontre:</strong> {product.meetingPoint}
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowOrderForm(false)}
                    className="flex-1 py-3 text-lg rounded-xl border-2 border-gray-300"
                  >
                    Annuler
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-sky-500 to-orange-500 hover:from-sky-600 hover:to-orange-600 py-3 text-lg rounded-xl font-semibold"
                  >
                    Confirmer la Commande
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
