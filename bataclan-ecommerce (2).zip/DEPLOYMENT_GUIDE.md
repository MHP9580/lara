# Guide de Déploiement BATACLAN (Version Simplifiée)

## 🚀 Déploiement sur Vercel

### 1. Préparation du Projet

1. **Télécharger le code** depuis v0
2. **Initialiser Git** :
   \`\`\`bash
   cd bataclan-ecommerce
   git init
   git add .
   git commit -m "Initial commit"
   \`\`\`

3. **Créer un repository GitHub** et pousser le code :
   \`\`\`bash
   git remote add origin https://github.com/votre-username/bataclan-ecommerce.git
   git push -u origin main
   \`\`\`

### 2. Configuration Supabase

1. **Créer un compte Supabase** : https://supabase.com
2. **Créer un nouveau projet** :
   - Nom : "bataclan-ecommerce"
   - Région : "Europe West" (plus proche de l'Afrique)
   - Mot de passe de base de données fort

3. **Exécuter les scripts SQL** :
   - Aller dans l'onglet "SQL Editor"
   - Copier-coller le contenu de \`scripts/01-create-tables.sql\`
   - Exécuter le script
   - Répéter avec \`scripts/02-seed-data.sql\`

4. **Récupérer les clés API** :
   - Aller dans Settings > API
   - Noter l'URL du projet et la clé "anon/public"

### 3. Déploiement sur Vercel

1. **Aller sur Vercel** : https://vercel.com
2. **Connecter votre GitHub** et importer le projet
3. **Configurer les variables d'environnement** :

\`\`\`env
# Supabase (OBLIGATOIRE)
NEXT_PUBLIC_SUPABASE_URL=https://votre-projet.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=votre-cle-anon
\`\`\`

4. **Déployer** : Vercel déploiera automatiquement

### 4. Configuration du Domaine (Optionnel)

1. **Acheter un domaine** (ex: bataclan.cg, bataclan.com)
2. **Dans Vercel** :
   - Aller dans Settings > Domains
   - Ajouter votre domaine personnalisé
   - Suivre les instructions DNS

## 📊 Gestion de la Base de Données

### Interface d'Administration Supabase

1. **Dashboard Supabase** : https://app.supabase.com
2. **Table Editor** : Voir et modifier les données
3. **SQL Editor** : Exécuter des requêtes personnalisées

### Requêtes Utiles

#### Voir toutes les commandes récentes
\`\`\`sql
SELECT 
  o.*,
  p.name as product_name,
  s.first_name || ' ' || s.last_name as seller_name
FROM orders o
JOIN products p ON o.product_id = p.id
JOIN sellers s ON o.seller_id = s.id
ORDER BY o.created_at DESC
LIMIT 50;
\`\`\`

#### Statistiques des ventes
\`\`\`sql
SELECT 
  COUNT(*) as total_orders,
  SUM(total_amount) as total_revenue,
  AVG(total_amount) as avg_order_value
FROM orders 
WHERE status = 'completed'
AND created_at >= NOW() - INTERVAL '30 days';
\`\`\`

## 🔧 Fonctionnalités

### ✅ Ce qui Fonctionne
- **Interface complète** avec vraies images
- **Système de commandes** avec codes de tickets
- **Base de données** persistante
- **Géolocalisation Congo** complète
- **Dashboard vendeur** fonctionnel
- **Design responsive** mobile/desktop

### 📱 Codes de Tickets
- **Génération automatique** : Format TK123456
- **Affichage sécurisé** : Code visible après commande
- **Copie facile** : Bouton pour copier le code
- **Instructions claires** : Guide pour l'utilisation

## 💰 Coûts

### Gratuit pour commencer :
- **Vercel** : Hébergement gratuit
- **Supabase** : 500MB base de données gratuite
- **Domaine** : ~20€/an (optionnel)

### Évolutif selon le succès :
- **Supabase Pro** : $25/mois (si >500MB)
- **Vercel Pro** : $20/mois (si >100GB trafic)

## 🎯 Checklist de Déploiement

### Phase 1 : Préparation (5 min)
- [ ] Télécharger le code depuis v0
- [ ] Créer repository GitHub
- [ ] Pousser le code

### Phase 2 : Base de Données (5 min)
- [ ] Créer compte Supabase
- [ ] Exécuter scripts SQL (copier-coller)
- [ ] Noter les clés API

### Phase 3 : Déploiement (5 min)
- [ ] Connecter Vercel à GitHub
- [ ] Ajouter variables d'environnement Supabase
- [ ] Déployer automatiquement

### Phase 4 : Test (5 min)
- [ ] Tester inscription vendeur
- [ ] Tester commande client
- [ ] Vérifier génération codes de tickets

## 🚀 Déploiement Express (15 min total)

Le site est maintenant **ultra-simplifié** :
- ❌ **Pas de SMS** à configurer
- ✅ **Codes de tickets** générés automatiquement
- ✅ **Interface moderne** avec vraies images
- ✅ **Base de données** optionnelle (fonctionne sans)
- ✅ **Déploiement immédiat** possible

## 📱 Test en Production

### URLs de Test
- **Site principal** : https://votre-domaine.vercel.app
- **Inscription vendeur** : /seller-register
- **Connexion vendeur** : /seller-login
- **Dashboard vendeur** : /seller-dashboard
- **Produit exemple** : /product/1

### Fonctionnalités Testables
- ✅ Navigation complète
- ✅ Commandes avec codes de tickets
- ✅ Interface vendeur
- ✅ Design responsive
- ✅ Images haute qualité

Le site est maintenant **prêt à déployer en 15 minutes** ! 🚀
