# BATACLAN - Marketplace du Congo Brazzaville

## Description du Projet

BATACLAN est une marketplace moderne développée avec Next.js, spécialement conçue pour le marché congolais. Le site permet aux utilisateurs d'acheter et de vendre des produits localement avec un système de rencontre en personne et de paiement sécurisé via des codes de tickets uniques.

## Fonctionnalités Principales

### Pour les Acheteurs
- ✅ Navigation libre sans inscription obligatoire
- ✅ Recherche de produits par catégorie et localisation
- ✅ Système de commande avec informations personnelles
- ✅ Génération automatique de codes de tickets uniques
- ✅ Notification SMS avec le code de ticket
- ✅ Contact direct avec les vendeurs
- ✅ Géolocalisation par provinces et quartiers du Congo Brazzaville

### Pour les Vendeurs
- ✅ Inscription avec vérification par téléphone (+242XXXXXXXXX)
- ✅ Interface de gestion complète (dashboard)
- ✅ Publication de produits avec photos et descriptions
- ✅ Gestion des commandes et notifications
- ✅ Système de messagerie avec les clients
- ✅ Profil vendeur avec évaluations
- ✅ ID vendeur unique
- ✅ Taxe mensuelle de 500 FCFA

### Fonctionnalités Techniques
- ✅ Design responsive avec Tailwind CSS
- ✅ Interface moderne avec shadcn/ui
- ✅ Couleurs dominantes : Bleu ciel et Orange
- ✅ Système d'authentification pour vendeurs
- ✅ Gestion des provinces et quartiers du Congo
- ✅ Format de téléphone congolais (+242XXXXXXXXX)
- ✅ Génération de tickets uniques
- ✅ Interface de discussion (en développement)

## Structure du Projet

\`\`\`
bataclan-ecommerce/
├── app/
│   ├── page.tsx                    # Page d'accueil
│   ├── seller-login/page.tsx       # Connexion vendeur
│   ├── seller-register/page.tsx    # Inscription vendeur
│   ├── seller-dashboard/page.tsx   # Dashboard vendeur
│   └── product/[id]/page.tsx       # Détail produit
├── components/
│   └── ui/                         # Composants shadcn/ui
└── README.md                       # Ce fichier
\`\`\`

## Rôles des Fichiers

### `app/page.tsx`
- Page d'accueil principale
- Affichage des produits en vedette
- Système de recherche et filtres
- Navigation par catégories
- Header avec logo BATACLAN stylisé

### `app/seller-login/page.tsx`
- Interface de connexion pour les vendeurs
- Validation du format de téléphone congolais
- Redirection vers le dashboard après connexion

### `app/seller-register/page.tsx`
- Formulaire d'inscription vendeur complet
- Upload de photo de profil
- Sélection province/quartier du Congo
- Validation des mots de passe
- Information sur la taxe mensuelle

### `app/seller-dashboard/page.tsx`
- Interface complète de gestion vendeur
- Onglets : Aperçu, Produits, Commandes, Messages, Profil
- Ajout/modification de produits
- Gestion des commandes avec codes de tickets
- Statistiques et notifications

### `app/product/[id]/page.tsx`
- Page détaillée d'un produit
- Informations vendeur et évaluations
- Formulaire de commande complet
- Génération de code de ticket unique
- Confirmation avec simulation SMS

## Installation et Test Local

### Prérequis
- Node.js 18+ installé
- VSCode (recommandé)

### Étapes d'installation

1. **Télécharger le projet**
   \`\`\`bash
   # Utiliser le bouton "Download Code" dans l'interface v0
   # Ou cloner si disponible sur GitHub
   \`\`\`

2. **Installer les dépendances**
   \`\`\`bash
   cd bataclan-ecommerce
   npm install
   \`\`\`

3. **Lancer le serveur de développement**
   \`\`\`bash
   npm run dev
   \`\`\`

4. **Ouvrir dans le navigateur**
   \`\`\`
   http://localhost:3000
   \`\`\`

### Test des Fonctionnalités

#### Tester l'Interface Acheteur
1. Naviguer sur la page d'accueil
2. Cliquer sur un produit pour voir les détails
3. Remplir le formulaire de commande
4. Vérifier la génération du code de ticket

#### Tester l'Interface Vendeur
1. Aller sur `/seller-register` pour créer un compte
2. Se connecter via `/seller-login`
3. Tester l'ajout de produits dans le dashboard
4. Vérifier la gestion des commandes

### Personnalisation

#### Modifier les Couleurs
Les couleurs principales sont définies dans les classes Tailwind :
- Bleu ciel : `sky-500`, `sky-600`, etc.
- Orange : `orange-500`, `orange-600`, etc.

#### Ajouter des Provinces/Quartiers
Modifier les tableaux dans les fichiers concernés :
\`\`\`javascript
const provinces = ['Brazzaville', 'Pointe-Noire', ...]
const quartiersByProvince = { ... }
\`\`\`

#### Intégration Backend
Pour une version production, remplacer les simulations par :
- API REST ou GraphQL
- Base de données (PostgreSQL, MySQL)
- Service SMS réel
- Système de paiement mobile money

## Technologies Utilisées

- **Framework** : Next.js 14 (App Router)
- **Styling** : Tailwind CSS
- **Composants** : shadcn/ui
- **Icons** : Lucide React
- **Déploiement** : Vercel (recommandé)

## Fonctionnalités Futures

- [ ] Système de paiement mobile money
- [ ] Géolocalisation GPS
- [ ] Notifications push
- [ ] Application mobile
- [ ] Système d'évaluations avancé
- [ ] Chat en temps réel
- [ ] Intégration avec les banques locales

## Support

Pour toute question ou problème :
- Email : contact@bataclan.cg
- Téléphone : +242 06 123 4567
- Adresse : Brazzaville, Congo

---

**BATACLAN** - La marketplace #1 du Congo Brazzaville 🇨🇬
