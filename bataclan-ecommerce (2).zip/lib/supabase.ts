import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Types pour TypeScript
export interface Seller {
  id: string
  seller_id: string
  first_name: string
  last_name: string
  phone: string
  email?: string
  profile_photo_url?: string
  province: string
  quartier: string
  address: string
  is_active: boolean
  monthly_fee_status: "pending" | "paid" | "overdue"
  monthly_fee_due_date: string
  rating: number
  total_reviews: number
  total_sales: number
  created_at: string
  updated_at: string
}

export interface Product {
  id: string
  seller_id: string
  name: string
  description?: string
  category_id: string
  price: number
  quantity: number
  condition: string
  meeting_point: string
  seller_phone: string
  images: string[]
  specifications?: any
  status: "active" | "inactive" | "sold_out"
  views_count: number
  orders_count: number
  created_at: string
  updated_at: string
  // Relations
  seller?: Seller
  category?: Category
}

export interface Category {
  id: string
  name: string
  description?: string
  icon?: string
  is_active: boolean
  created_at: string
}

export interface Order {
  id: string
  ticket_code: string
  product_id: string
  seller_id: string
  customer_first_name: string
  customer_last_name: string
  customer_phone: string
  customer_province: string
  customer_quartier: string
  customer_address: string
  customer_message?: string
  quantity: number
  unit_price: number
  total_amount: number
  status: "pending" | "confirmed" | "completed" | "cancelled"
  created_at: string
  updated_at: string
  // Relations
  product?: Product
  seller?: Seller
}

export interface Location {
  id: string
  province: string
  quartier: string
  is_active: boolean
}
