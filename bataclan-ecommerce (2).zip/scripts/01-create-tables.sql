-- Création des tables pour BATACLAN (Version simplifiée sans SMS)

-- Table des vendeurs
CREATE TABLE sellers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    seller_id VARCHAR(20) UNIQUE NOT NULL, -- Format: VND001, VND002, etc.
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(15) UNIQUE NOT NULL, -- Format: +242XXXXXXXXX
    email VARCHAR(255),
    password_hash VARCHAR(255) NOT NULL,
    profile_photo_url TEXT,
    province VARCHAR(100) NOT NULL,
    quartier VARCHAR(100) NOT NULL,
    address TEXT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    monthly_fee_status VARCHAR(20) DEFAULT 'pending', -- pending, paid, overdue
    monthly_fee_due_date DATE,
    rating DECIMAL(3,2) DEFAULT 0.00,
    total_reviews INTEGER DEFAULT 0,
    total_sales INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des catégories
CREATE TABLE categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    icon VARCHAR(50),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des produits
CREATE TABLE products (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    seller_id UUID REFERENCES sellers(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    category_id UUID REFERENCES categories(id),
    price DECIMAL(12,2) NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 0,
    condition VARCHAR(50) DEFAULT 'new', -- new, used, refurbished
    meeting_point TEXT NOT NULL,
    seller_phone VARCHAR(15) NOT NULL,
    images TEXT[], -- Array of image URLs
    specifications JSONB,
    status VARCHAR(20) DEFAULT 'active', -- active, inactive, sold_out
    views_count INTEGER DEFAULT 0,
    orders_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des commandes (sans champs SMS)
CREATE TABLE orders (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    ticket_code VARCHAR(20) UNIQUE NOT NULL, -- Format: TK123456
    product_id UUID REFERENCES products(id),
    seller_id UUID REFERENCES sellers(id),
    customer_first_name VARCHAR(100) NOT NULL,
    customer_last_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(15) NOT NULL,
    customer_province VARCHAR(100) NOT NULL,
    customer_quartier VARCHAR(100) NOT NULL,
    customer_address TEXT NOT NULL,
    customer_message TEXT,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_price DECIMAL(12,2) NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- pending, confirmed, completed, cancelled
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des messages/discussions
CREATE TABLE messages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    sender_type VARCHAR(20) NOT NULL, -- 'customer' or 'seller'
    sender_phone VARCHAR(15) NOT NULL,
    seller_id UUID REFERENCES sellers(id),
    product_id UUID REFERENCES products(id),
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des avis/évaluations
CREATE TABLE reviews (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    seller_id UUID REFERENCES sellers(id),
    order_id UUID REFERENCES orders(id),
    customer_phone VARCHAR(15) NOT NULL,
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Table des provinces et quartiers du Congo
CREATE TABLE locations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    province VARCHAR(100) NOT NULL,
    quartier VARCHAR(100) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    UNIQUE(province, quartier)
);

-- Index pour optimiser les performances
CREATE INDEX idx_products_seller_id ON products(seller_id);
CREATE INDEX idx_products_category_id ON products(category_id);
CREATE INDEX idx_products_status ON products(status);
CREATE INDEX idx_orders_seller_id ON orders(seller_id);
CREATE INDEX idx_orders_ticket_code ON orders(ticket_code);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_messages_seller_id ON messages(seller_id);
CREATE INDEX idx_sellers_phone ON sellers(phone);
CREATE INDEX idx_sellers_seller_id ON sellers(seller_id);
