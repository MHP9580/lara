-- Insertion des données initiales

-- Catégories
INSERT INTO categories (name, description, icon) VALUES
('Électronique', 'Téléphones, ordinateurs, accessoires tech', '📱'),
('Mode', 'Vêtements, chaussures, accessoires', '👕'),
('Maison', 'Meubles, décoration, électroménager', '🏠'),
('Sport', 'Équipements sportifs, vêtements de sport', '⚽'),
('Beauté', 'Cosmétiques, parfums, soins', '💄'),
('Automobile', 'Voitures, motos, pièces détachées', '🚗'),
('Alimentation', 'Produits alimentaires, boissons', '🍎'),
('Livres', 'Livres, magazines, matériel éducatif', '📚');

-- Provinces et quartiers du Congo Brazzaville
INSERT INTO locations (province, quartier) VALUES
-- Brazzaville
('Brazzaville', 'Poto-Poto'),
('Brazzaville', 'Bacongo'),
('Brazzaville', 'Moungali'),
('Brazzaville', 'Ouenzé'),
('Brazzaville', 'Talangaï'),
('Brazzaville', 'Mfilou'),
('Brazzaville', 'Djiri'),
('Brazzaville', 'Madibou'),

-- Pointe-Noire
('Pointe-Noire', 'Centre-ville'),
('Pointe-Noire', 'Tié-Tié'),
('Pointe-Noire', 'Lumumba'),
('Pointe-Noire', 'Mongo-Mpoukou'),
('Pointe-Noire', 'Ngoyo'),
('Pointe-Noire', 'Mvou-Mvou'),

-- Autres provinces
('Dolisie', 'Centre'),
('Dolisie', 'Ngot'),
('Dolisie', 'Moukoukoulou'),
('Dolisie', 'Bikoumat'),

('Nkayi', 'Centre'),
('Nkayi', 'Loudima'),
('Nkayi', 'Mouyondzi'),

('Impfondo', 'Centre'),
('Impfondo', 'Dongou'),
('Impfondo', 'Epena'),

('Ouesso', 'Centre'),
('Ouesso', 'Pokola'),
('Ouesso', 'Kabo'),

('Madingou', 'Centre'),
('Madingou', 'Divénié'),
('Madingou', 'Kimongo'),

('Owando', 'Centre'),
('Owando', 'Makoua'),
('Owando', 'Okoyo');

-- Vendeur de démonstration
INSERT INTO sellers (
    seller_id, first_name, last_name, phone, password_hash,
    province, quartier, address, monthly_fee_due_date
) VALUES (
    'VND001', 'Jean', 'Mbemba', '+242065123456', 
    '$2b$10$example_hash_here', -- En production, utiliser bcrypt
    'Brazzaville', 'Poto-Poto', 
    'Avenue de l''Indépendance, Poto-Poto',
    CURRENT_DATE + INTERVAL '30 days'
);
