// Script Node.js pour gérer la base de données BATACLAN
// Usage: node scripts/database-manager.js [command]

import { createClient } from "@supabase/supabase-js"
import bcrypt from "bcryptjs"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY // Clé service pour admin

if (!supabaseUrl || !supabaseServiceKey) {
  console.error("❌ Variables d'environnement Supabase manquantes")
  process.exit(1)
}

const supabase = createClient(supabaseUrl, supabaseServiceKey)

// Commandes disponibles
const commands = {
  stats: showStats,
  orders: showRecentOrders,
  sellers: showSellers,
  cleanup: cleanupOldData,
  "create-seller": createTestSeller,
  backup: backupData,
  help: showHelp,
}

async function main() {
  const command = process.argv[2] || "help"

  if (commands[command]) {
    console.log(`🚀 Exécution de la commande: ${command}`)
    await commands[command]()
  } else {
    console.log(`❌ Commande inconnue: ${command}`)
    showHelp()
  }
}

async function showStats() {
  console.log("\n📊 STATISTIQUES BATACLAN")
  console.log("=".repeat(50))

  try {
    // Statistiques générales
    const { data: sellers } = await supabase.from("sellers").select("id", { count: "exact" })
    const { data: products } = await supabase.from("products").select("id", { count: "exact" })
    const { data: orders } = await supabase.from("orders").select("id", { count: "exact" })

    console.log(`👥 Vendeurs actifs: ${sellers?.length || 0}`)
    console.log(`📦 Produits en ligne: ${products?.length || 0}`)
    console.log(`🛒 Commandes totales: ${orders?.length || 0}`)

    // Revenus
    const { data: revenue } = await supabase.from("orders").select("total_amount").eq("status", "completed")

    const totalRevenue = revenue?.reduce((sum, order) => sum + Number(order.total_amount), 0) || 0
    console.log(`💰 Chiffre d'affaires: ${totalRevenue.toLocaleString()} FCFA`)

    // Commandes récentes (7 derniers jours)
    const weekAgo = new Date()
    weekAgo.setDate(weekAgo.getDate() - 7)

    const { data: recentOrders } = await supabase.from("orders").select("id").gte("created_at", weekAgo.toISOString())

    console.log(`📈 Commandes (7 derniers jours): ${recentOrders?.length || 0}`)
  } catch (error) {
    console.error("❌ Erreur lors de la récupération des statistiques:", error.message)
  }
}

async function showRecentOrders() {
  console.log("\n🛒 COMMANDES RÉCENTES")
  console.log("=".repeat(50))

  try {
    const { data: orders, error } = await supabase
      .from("orders")
      .select(`
        ticket_code,
        customer_first_name,
        customer_last_name,
        customer_phone,
        total_amount,
        status,
        created_at,
        products(name),
        sellers(first_name, last_name)
      `)
      .order("created_at", { ascending: false })
      .limit(10)

    if (error) throw error

    orders?.forEach((order) => {
      console.log(`\n🎫 ${order.ticket_code}`)
      console.log(`   Client: ${order.customer_first_name} ${order.customer_last_name}`)
      console.log(`   Téléphone: ${order.customer_phone}`)
      console.log(`   Produit: ${order.products?.name}`)
      console.log(`   Vendeur: ${order.sellers?.first_name} ${order.sellers?.last_name}`)
      console.log(`   Montant: ${order.total_amount} FCFA`)
      console.log(`   Statut: ${order.status}`)
      console.log(`   Date: ${new Date(order.created_at).toLocaleString("fr-FR")}`)
    })
  } catch (error) {
    console.error("❌ Erreur lors de la récupération des commandes:", error.message)
  }
}

async function showSellers() {
  console.log("\n👥 VENDEURS ACTIFS")
  console.log("=".repeat(50))

  try {
    const { data: sellers, error } = await supabase
      .from("sellers")
      .select(`
        seller_id,
        first_name,
        last_name,
        phone,
        province,
        quartier,
        is_active,
        monthly_fee_status,
        total_sales,
        rating,
        created_at
      `)
      .eq("is_active", true)
      .order("created_at", { ascending: false })

    if (error) throw error

    sellers?.forEach((seller) => {
      console.log(`\n🏪 ${seller.seller_id}`)
      console.log(`   Nom: ${seller.first_name} ${seller.last_name}`)
      console.log(`   Téléphone: ${seller.phone}`)
      console.log(`   Localisation: ${seller.quartier}, ${seller.province}`)
      console.log(`   Ventes: ${seller.total_sales}`)
      console.log(`   Note: ${seller.rating}/5`)
      console.log(`   Taxe: ${seller.monthly_fee_status}`)
      console.log(`   Inscrit: ${new Date(seller.created_at).toLocaleDateString("fr-FR")}`)
    })
  } catch (error) {
    console.error("❌ Erreur lors de la récupération des vendeurs:", error.message)
  }
}

async function cleanupOldData() {
  console.log("\n🧹 NETTOYAGE DES DONNÉES")
  console.log("=".repeat(50))

  try {
    // Supprimer les commandes annulées de plus de 30 jours
    const thirtyDaysAgo = new Date()
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

    const { data: deletedOrders, error: orderError } = await supabase
      .from("orders")
      .delete()
      .eq("status", "cancelled")
      .lt("created_at", thirtyDaysAgo.toISOString())
      .select("id")

    if (orderError) throw orderError

    console.log(`🗑️ Commandes annulées supprimées: ${deletedOrders?.length || 0}`)

    // Supprimer les messages de plus de 90 jours
    const ninetyDaysAgo = new Date()
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90)

    const { data: deletedMessages, error: messageError } = await supabase
      .from("messages")
      .delete()
      .lt("created_at", ninetyDaysAgo.toISOString())
      .select("id")

    if (messageError) throw messageError

    console.log(`💬 Messages anciens supprimés: ${deletedMessages?.length || 0}`)

    console.log("✅ Nettoyage terminé")
  } catch (error) {
    console.error("❌ Erreur lors du nettoyage:", error.message)
  }
}

async function createTestSeller() {
  console.log("\n👤 CRÉATION D'UN VENDEUR DE TEST")
  console.log("=".repeat(50))

  try {
    const testSeller = {
      seller_id: "VND" + Date.now().toString().slice(-3),
      first_name: "Test",
      last_name: "Vendeur",
      phone: "+242065" + Math.random().toString().slice(-6),
      password_hash: await bcrypt.hash("password123", 10),
      province: "Brazzaville",
      quartier: "Poto-Poto",
      address: "Adresse de test, Poto-Poto",
      monthly_fee_due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    }

    const { data, error } = await supabase.from("sellers").insert(testSeller).select().single()

    if (error) throw error

    console.log("✅ Vendeur de test créé:")
    console.log(`   ID: ${data.seller_id}`)
    console.log(`   Téléphone: ${data.phone}`)
    console.log(`   Mot de passe: password123`)
  } catch (error) {
    console.error("❌ Erreur lors de la création du vendeur:", error.message)
  }
}

async function backupData() {
  console.log("\n💾 SAUVEGARDE DES DONNÉES")
  console.log("=".repeat(50))

  try {
    const timestamp = new Date().toISOString().split("T")[0]

    // Exporter les données principales
    const tables = ["sellers", "products", "orders", "categories"]

    for (const table of tables) {
      const { data, error } = await supabase.from(table).select("*")

      if (error) throw error

      const fs = await import("fs")
      const filename = `backup_${table}_${timestamp}.json`

      fs.writeFileSync(filename, JSON.stringify(data, null, 2))
      console.log(`✅ ${table}: ${data?.length || 0} enregistrements → ${filename}`)
    }

    console.log(`\n💾 Sauvegarde terminée dans les fichiers backup_*_${timestamp}.json`)
  } catch (error) {
    console.error("❌ Erreur lors de la sauvegarde:", error.message)
  }
}

function showHelp() {
  console.log("\n📖 GESTIONNAIRE DE BASE DE DONNÉES")
  console.log("=".repeat(50))
  console.log("Les commandes disponibles sont:")
  console.log("  stats: Afficher les statistiques de la base de données")
  console.log("  orders: Afficher les commandes récentes")
  console.log("  sellers: Afficher les vendeurs actifs")
  console.log("  cleanup: Nettoyer les données anciennes")
  console.log("  create-seller: Créer un vendeur de test")
  console.log("  backup: Sauvegarder les données de la base de données")
  console.log("  help: Afficher cette aide")
}
